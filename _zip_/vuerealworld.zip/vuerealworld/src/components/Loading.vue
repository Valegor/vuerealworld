<template>
  <div>
    Loading...
  </div>
</template>

<script>
export default {
  name: 'McvLoading'
}
</script>
